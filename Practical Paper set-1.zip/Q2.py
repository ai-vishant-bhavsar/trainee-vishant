def is_armstrong(num):
	sum = 0
	for i in str(num):
		sum += int(i) ** len(str(num))
	if sum == num:
		return True
	else:
		return False

while True:
	try:
		num = int(input("Enter a number to check, number is armstrong or not : "))
		print(is_armstrong(num))
		break
	except TypeError:
		print("Invalid Input!")
		continue


