import psycopg2
import csv

conn = psycopg2.connect(
		database = "sell_order",
		user = "odoo",
		host = "127.0.0.1",
		password = "odoo",
		port = 5432)

cursor = conn.cursor()

cursor.execute('''
		SELECT Customers.Customer_ID, Customers.Customer_Name, COALESCE(Products.Product_Name) AS Product_Name, COALESCE(Products.Product_ID) AS Product_ID,COALESCE(Orders.Quantity) AS Quantity, COALESCE(Orders.Order_date) AS Order_Date
		FROM Customers
		LEFT JOIN Orders ON Customers.Customer_ID = Orders.Customer_ID
		LEFT JOIN Products ON Products.Product_ID = Orders.Product_ID;''')

result = cursor.fetchall()
for i in result:
	for j in i:
		print (f"{j}\t", end = "")
	print("")
	
with open('PSQL_Python_1.csv', 'w') as f:
	writer = csv.writer(f, delimiter=',')
	for i in result:
		writer.writerow(i)

conn.commit()

cursor.close()
conn.close()
