import psycopg2
import csv

conn = psycopg2.connect(
		database = "sell_order",
		user = "odoo",
		host = "127.0.0.1",
		password = "odoo",
		port = 5432)

cursor = conn.cursor()
		
cursor.execute('''
		SELECT Customers.Customer_ID, Customers.Customer_Name, Products.Product_Name, Products.Price, Orders.Quantity, (Products.Price * Orders.Quantity) AS Total_Price
		FROM Customers
		INNER JOIN Orders ON Customers.Customer_ID = Orders.Customer_ID
		INNER JOIN Products ON Products.Product_ID = Orders.Product_ID;''')

result = cursor.fetchall()
for i in result:
	for j in i:
		print (f"{j}\t", end = "")
	print("")

with open('PSQL_Python_3.csv', 'w') as f:
	writer = csv.writer(f, delimiter=',')
	for i in result:
		writer.writerow(i)

conn.commit()

cursor.close()
conn.close()
