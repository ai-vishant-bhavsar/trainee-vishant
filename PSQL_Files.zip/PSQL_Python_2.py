import psycopg2
import csv

conn = psycopg2.connect(
		database = "sell_order",
		user = "odoo",
		host = "127.0.0.1",
		password = "odoo",
		port = 5432)

cursor = conn.cursor()
		
cursor.execute('''
		SELECT Products.Product_ID, Products.Product_Name  FROM Orders
		RIGHT JOIN Products ON Products.Product_ID = Orders.Product_ID
		WHERE Products.Product_ID NOT IN (SELECT Product_ID FROM Orders);''')


result = cursor.fetchall()
for i in result:
	for j in i:
		print (f"{j}\t", end = "")
	print("")
	
with open('PSQL_Python_2.csv', 'w') as f:
	writer = csv.writer(f, delimiter=',')
	for i in result:
		writer.writerow(i)

conn.commit()

cursor.close()
conn.close()
