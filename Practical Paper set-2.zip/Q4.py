company = {
    'Robert Downey': {
        'role': 'Project Manager',
        'team': {
            'Mark': {'role': 'Team Lead', 'experience': 8, 'mentor': None},
            'Samuel': {'role': 'Team Lead', 'experience': 8, 'mentor': None},
            'Paul': {'role': 'Team Lead', 'experience': 8, 'mentor': None},
            'Tom': {'role': 'Team Lead', 'experience': 8, 'mentor': None},
        }
    },
    'Anne Hathaway': {
        'role': 'Project Manager',
        'team': {
            'Chris': {'role': 'Team Lead', 'experience': 5, 'mentor': None},
            'Pratt': {'role': 'Team Lead', 'experience': 5, 'mentor': None},
            'Emma': {'role': 'Team Lead', 'experience': 5, 'mentor': None},
            'Will': {'role': 'Team Lead', 'experience': 5, 'mentor': None},
            'Smith': {'role': 'Team Lead', 'experience': 5, 'mentor': None},
        }
    },
    'James': {
        'role': 'Team Lead',
        'experience': 3.8,
        'mentor': 'Chris',
        'team': {
            'Jennifer': {'role': 'Senior Developer', 'experience': 3.8, 'mentor': 'James'},
            'Scott': {'role': 'Senior Developer', 'experience': 3.8, 'mentor': 'James'},
            'Sophie': {'role': 'Senior Developer', 'experience': 3.8, 'mentor': 'James'},
        }
    },
    'Fergal': {
        'role': 'Senior Developer',
        'experience': 4.5,
        'mentor': 'Paul',
    },
    'Edge': {
        'role': 'Senior Developer',
        'experience': 3,
        'mentor': 'Will',
    },
    'Ryan': {
        'role': 'Senior Developer',
        'experience': 3.5,
        'mentor': 'Will',
    },
    'Jerry': {
        'role': 'Junior Developer',
        'experience': 1.5,
        'mentor': 'Tom',
    },
    'John': {
        'role': 'Junior Developer',
        'experience': 1.6,
        'mentor': 'Tom',
    },
    'Leonardo': {
        'role': 'Junior Developer',
        'experience': 1,
        'mentor': 'Mark',
    },
    'Alexandra': {
        'role': 'Junior Developer',
        'experience': 1,
        'mentor': 'Mark',
    },
    'Walker': {
        'role': 'Senior Developer',
        'experience': 2.7,
        'mentor': 'Smith',
    },
    'Diana': {
        'role': 'Senior Developer',
        'experience': 2.7,
        'mentor': 'Smith',
    }
}

def display_employees_by_manager(manager_name):
    if manager_name in company:
        if 'team' in company[manager_name]:
            return list(company[manager_name]['team'].keys())
        return []
    return []

def employees_experience_above_4():
    result = []
    for employee, details in company.items():
        if isinstance(details, dict) and details.get('experience', 0) > 4:
            result.append(employee)
        elif isinstance(details, dict) and 'team' in details:
            for team_member, team_details in details['team'].items():
                if team_details['experience'] > 4:
                    result.append(team_member)
    return result

def update_experience():
    for employee, details in company.items():
        if isinstance(details, dict) and 'experience' in details:
            if 3.5 < details['experience'] < 4.5:
                details['experience'] = 4.6
        elif isinstance(details, dict) and 'team' in details:
            for team_member, team_details in details['team'].items():
                if 3.5 < team_details['experience'] < 4.5:
                    team_details['experience'] = 4.6

def display_tl_experience():
    result = []
    for employee, details in company.items():
        if isinstance(details, dict) and details.get('role') == 'Project Manager':
            for tl, tl_details in details['team'].items():
                experience = tl_details['experience'] if 'experience' in tl_details else 'N/A'
                result.append(f"{tl}: {experience}")
    return result

def assign_smith_team_to_ryan():
    for employee, details in company.items():
        if isinstance(details, dict) and 'team' in details:
            if 'Smith' in details['team']:
                for member in details['team']['Smith']:
                    team_member_details = details['team']['Smith'][member]
                    details['mentor'] = 'Ryan'
                del details['team']['Smith']


def check_employee_less_than_2_years():
    result = []
    for employee, details in company.items():
        if isinstance(details, dict) and details.get('experience', 3) < 2:
            result.append(employee)
        elif isinstance(details, dict) and 'team' in details:
            for team_member, team_details in details['team'].items():
                if team_details['experience'] < 2:
                    result.append(team_member)
    return result

def check_and_make_edge_tl():
    if 'Edge' in company and company['Edge']['role'] != 'Team Lead':
        company['Edge']['role'] = 'Team Lead'
        company['Edge']['experience'] = 'N/A'

print("Display employees of Robert Downey manage: ",end="")
print(display_employees_by_manager("Robert Downey"))
print("")

print("Employees experiance above 4 years: ", end="")
print(employees_experience_above_4())
print("")

print(f"Updated experiance: {update_experience()}")
print("")
print(display_tl_experience())
print('')

print("Assign a team Smith to Ryan: ", end="")
assign_smith_team_to_ryan()

print("")

print("Employees who has less than 2 year of experiance: ",end="")
print(check_employee_less_than_2_years())
print("")

print("Making a edge a team leader: ",end="")
check_and_make_edge_tl()
print(company['Edge'])
print("")
