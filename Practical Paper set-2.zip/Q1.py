from collections import Counter

def find_repeated_words(sentence):
    words = sentence.split()
    word_count = Counter(words)
    repeated_words = [word for word, count in word_count.items() if count > 1]
    return ' # '.join(repeated_words)

sentence = "apple orange banana apple grape banana apple"
result = find_repeated_words(sentence)
print(result)