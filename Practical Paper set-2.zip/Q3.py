def filter_numbers(numbers):
    filtered_numbers = []

    for num in numbers:
        if 1000 <= num <= 9999:
            first_digit = int(str(num)[0])
            last_digit = num % 10
            if first_digit % 2 != 0 and last_digit % 2 == 0:
                if num % 3 == 0 or num % 7 == 0:
                    filtered_numbers.append(num)

    return filtered_numbers


user_input = input("Enter a list of numbers separated by spaces: ")
numbers = list(map(int, user_input.split()))
result = filter_numbers(numbers)
print("Filtered numbers:", result)