def extract_strings(list1):
    vowels = 'AEIOUaeiou'
    result = [word for word in list1 if word[0].isalpha() and word[0].upper() not in vowels and word[0].isupper() and not any(char.isdigit() for char in word)]
    return result

list1 = input("Enter a list of strings separated by spaces: ").split()
print("User input list:", list1)
result = extract_strings(list1)
print("Filtered result:", result)
