class Product:
    def __init__(self, name, cost_prices, sale_percentages):
        self.name = name
        self.cost_prices = cost_prices
        self.sale_percentages = sale_percentages
        self.sale_prices = {}

        for month, cost_price_list in cost_prices.items():
            sale_percentage = sale_percentages.get(month, 0)
            self.sale_prices[month] = [price + (price * sale_percentage / 100) for price in cost_price_list]

    def update_sale_price(self, percentage, month):
        if month in self.cost_prices:
            self.sale_prices[month] = [price + (price * percentage / 100) for price in self.cost_prices[month]]

    def reset_cost_price(self, month):
        if month in self.cost_prices:
            self.cost_prices[month] = [0] * len(self.cost_prices[month])

    def add_month(self, month, cost_prices, sale_percentage):
        if month not in self.cost_prices:
            self.cost_prices[month] = cost_prices
            self.sale_percentages[month] = sale_percentage
            self.sale_prices[month] = [price + (price * sale_percentage / 100) for price in cost_prices]

    def remove_month(self, month):
        if month in self.cost_prices:
            del self.cost_prices[month]
            del self.sale_percentages[month]
            del self.sale_prices[month]

    def get_average_cost_and_sale(self, month):
        if month in self.cost_prices:
            avg_cost = sum(self.cost_prices[month]) / len(self.cost_prices[month])
            avg_sale = sum(self.sale_prices[month]) / len(self.sale_prices[month])
            return avg_cost, avg_sale


class Shelf:
    def __init__(self, name):
        self.name = name
        self.products = {}

    def add_product(self, product):
        self.products[product.name] = product

    def update_shelf_sale_price(self, percentage, month):
        for product in self.products.values():
            product.update_sale_price(percentage, month)

    def set_category_for_product(self, product_name, category):
        if product_name in self.products:
            self.products[product_name].category = category

    def reset_cost_price_for_product(self, product_name, month):
        if product_name in self.products:
            self.products[product_name].reset_cost_price(month)

    def get_max_min_price(self, product_name):
        if product_name in self.products:
            product = self.products[product_name]
            max_price = max(product.sale_prices.values())
            min_price = min(product.sale_prices.values())
            return max_price, min_price

    def get_average_cost_and_sale(self, month):
        total_cost = 0
        total_sale = 0
        total_profit = 0
        num_products = len(self.products)
        
        for product in self.products.values():
            avg_cost, avg_sale = product.get_average_cost_and_sale(month)
            total_cost += avg_cost
            total_sale += avg_sale
            total_profit += (avg_sale - avg_cost)

        avg_cost = total_cost / num_products
        avg_sale = total_sale / num_products
        avg_profit = total_profit / num_products
        
        return avg_cost, avg_sale, avg_profit

    def get_average_cost_and_sale_for_product(self, product_name, month):
        if product_name in self.products:
            product = self.products[product_name]
            avg_cost, avg_sale = product.get_average_cost_and_sale(month)
            return avg_cost, avg_sale, avg_sale - avg_cost

    def print_shelf(self):
        print(f"Shelf Name: {self.name}")
        shelf_data = {}
        for product in self.products.values():
            product_data = {
                'cost_prices': product.cost_prices,
                'sale_prices': product.sale_prices,
                'sale_percentages': product.sale_percentages
            }
            shelf_data[product.name] = product_data
        print(shelf_data)


def create_shelf():
    shelf_name = input("Enter shelf name (e.g., SHELF-1, SHELF-2): ")
    shelf = Shelf(shelf_name)

    num_products = int(input("Enter the number of products to add to this shelf: "))
    
    for i in range(num_products):
        product_name = input(f"Enter product {i+1} name: ")
        
        cost_prices = {}
        sale_percentages = {}
        
        months = input("Enter months (comma separated, e.g., January, February): ").split(',')
        for month in months:
            month = month.strip()
            num_costs = int(input(f"Enter number of costs for {product_name} in {month}: "))
            costs = [float(input(f"Enter cost {i+1} for {month}: ")) for i in range(num_costs)]
            cost_prices[month] = costs
            
            sale_percentage = float(input(f"Enter sale percentage for {month}: "))
            sale_percentages[month] = sale_percentage
        
        product = Product(product_name, cost_prices, sale_percentages)
        shelf.add_product(product)

    return shelf


def main():
    shelves = {}

    while True:
        print("\nChoose an operation:")
        print("1. Create a new shelf")
        print("2. Add month to a product")
        print("3. Remove month from a product")
        print("4. Update sale prices for a shelf")
        print("5. Set category for a product")
        print("6. Reset cost prices for a product")
        print("7. Get max/min price for a product")
        print("8. Get average cost, sale, and profit for a shelf")
        print("9. Get average cost, sale, and profit for a product")
        print("10. Print all shelves")
        print("11. Exit")
        
        choice = input("Enter choice (1-11): ").strip()

        if choice == '1':
            shelf = create_shelf()
            shelves[shelf.name] = shelf
            print(f"Shelf {shelf.name} created successfully.")
        
        elif choice == '2':
            shelf_name = input("Enter shelf name to add month to a product: ")
            if shelf_name in shelves:
                product_name = input("Enter product name: ")
                month = input("Enter the month to add: ").strip()
                num_costs = int(input(f"Enter number of costs for {product_name} in {month}: "))
                costs = [float(input(f"Enter cost {i+1} for {month}: ")) for i in range(num_costs)]
                sale_percentage = float(input(f"Enter sale percentage for {month}: "))
                
                shelf = shelves[shelf_name]
                if product_name in shelf.products:
                    product = shelf.products[product_name]
                    product.add_month(month, costs, sale_percentage)
                    print(f"Month {month} added for {product_name}.")
                else:
                    print(f"Product {product_name} not found.")
            else:
                print(f"Shelf {shelf_name} not found.")
        
        elif choice == '3':
            shelf_name = input("Enter shelf name to remove month from a product: ")
            if shelf_name in shelves:
                product_name = input("Enter product name: ")
                month = input("Enter the month to remove: ").strip()
                
                shelf = shelves[shelf_name]
                if product_name in shelf.products:
                    product = shelf.products[product_name]
                    product.remove_month(month)
                    print(f"Month {month} removed for {product_name}.")
                else:
                    print(f"Product {product_name} not found.")
            else:
                print(f"Shelf {shelf_name} not found.")
        
        elif choice == '4':
            shelf_name = input("Enter shelf name to update sale prices: ")
            if shelf_name in shelves:
                month = input("Enter the month to update sale prices (e.g., January): ").strip()
                percentage = float(input("Enter the percentage to update sale prices by: "))
                shelves[shelf_name].update_shelf_sale_price(percentage, month)
                print(f"Sale prices updated for {shelf_name} in {month}.")
            else:
                print(f"Shelf {shelf_name} not found.")
        
        elif choice == '5':
            shelf_name = input("Enter shelf name: ")
            if shelf_name in shelves:
                product_name = input("Enter product name to set category: ")
                category = input(f"Enter category for {product_name}: ")
                shelves[shelf_name].set_category_for_product(product_name, category)
                print(f"Category for {product_name} set to {category}.")
            else:
                print(f"Shelf {shelf_name} not found.")
        
        elif choice == '6':
            shelf_name = input("Enter shelf name to reset cost price for a product: ")
            if shelf_name in shelves:
                product_name = input("Enter product name: ")
                month = input("Enter month to reset cost prices: ").strip()
                shelves[shelf_name].reset_cost_price_for_product(product_name, month)
                print(f"Cost prices for {product_name} in {month} reset to 0.")
            else:
                print(f"Shelf {shelf_name} not found.")
        
        elif choice == '7':
            shelf_name = input("Enter shelf name: ")
            if shelf_name in shelves:
                product_name = input("Enter product name to get max/min price: ")
                max_price, min_price = shelves[shelf_name].get_max_min_price(product_name)
                print(f"Max price: {max_price}, Min price: {min_price}")
            else:
                print(f"Shelf {shelf_name} not found.")
        
        elif choice == '8':
            shelf_name = input("Enter shelf name to get average cost, sale, and profit: ")
            if shelf_name in shelves:
                month = input("Enter month (e.g., January) to get the average cost, sale, and profit: ").strip()
                avg_cost, avg_sale, avg_profit = shelves[shelf_name].get_average_cost_and_sale(month)
                print(f"Average cost: {avg_cost}, Average sale: {avg_sale}, Average profit: {avg_profit}")
            else:
                print(f"Shelf {shelf_name} not found.")
        
        elif choice == '9':
            shelf_name = input("Enter shelf name: ")
            if shelf_name in shelves:
                product_name = input("Enter product name to get average cost, sale, and profit: ")
                month = input("Enter month (e.g., January) to get the average cost, sale, and profit: ").strip()
                avg_cost, avg_sale, profit = shelves[shelf_name].get_average_cost_and_sale_for_product(product_name, month)
                print(f"Product {product_name} - Average cost: {avg_cost}, Average sale: {avg_sale}, Profit: {profit}")
            else:
                print(f"Shelf {shelf_name} not found.")
        
        elif choice == '10':
            print("\nAll Shelves and Products:")
            for shelf in shelves.values():
                shelf.print_shelf()

        elif choice == '11':
            print("Exiting...")
            break

if __name__ == "__main__":
    main()
