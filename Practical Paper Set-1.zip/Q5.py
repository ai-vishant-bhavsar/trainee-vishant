def check_four_digit_condition(num):
    if num < 1000 or num > 9999:
        return False
    return True

def check_second_last_digit_condition(num):
    num_str = str(num)
    if len(num_str) == 2:
        second_digit = int(num_str[1])
        if second_digit % 2 == 0:
            return False
    elif len(num_str) >= 3:
        second_digit = int(num_str[1])
        last_digit = int(num_str[-1])
        if second_digit % 2 == 0 or last_digit % 2 != 0:
            return False
    return True

def check_divisibility_condition(num):
    if num % 8 != 0 and num % 5 != 0:
        return False
    return True


user_input = input("Enter a list of numbers (comma separated): ")
numbers = [int(x) for x in user_input.split(",")]


valid_four_digit_numbers = [num for num in numbers if check_four_digit_condition(num)]
print("\nList of numbers which has 4 digits")
print("Valid 4-digit numbers:", valid_four_digit_numbers)


valid_second_last_digit_numbers = [num for num in numbers if check_second_last_digit_condition(num)]
print("\nList of number which has second digit odd and last digit even")
print("Valid numbers with second digit odd and last digit even:", valid_second_last_digit_numbers)


valid_divisible_numbers = [num for num in numbers if check_divisibility_condition(num)]
print("\nList of numbers which are divisible by 8 or 5")
print("Valid numbers divisible by 8 or 5:", valid_divisible_numbers)


valid_numbers = [num for num in numbers if check_four_digit_condition(num) and
                 check_second_last_digit_condition(num) and 
                 check_divisibility_condition(num)]
print("\nAll Conditions Combined")
print("Valid numbers based on all conditions:", valid_numbers)
