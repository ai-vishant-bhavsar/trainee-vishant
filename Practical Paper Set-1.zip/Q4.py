List_of_string = []
def List_input():
	while True:
		string = input("Enter a stirng(exit() to exit): ")
		if string == 'exit()':
			break
		else:
			List_of_string.append(string)


List_input()
print("The first charactor is lower and consonant: ")
for i in List_of_string:
	if i[0].islower() and i[0] not in 'aeiou':
		print (i end=" ")


print("\n\n\nThe string must not contain any number or any special charactors : ")
for i in List_of_string:
	if i.isnumeric() or i.isalpha():
		if not i.isnumeric():
			print(i, end=' ')
print("\n")

