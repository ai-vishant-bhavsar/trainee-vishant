def is_armstrong(num):
	sum = 0
	for i in str(num):
		sum += int(i) ** 3
		print(sum)
	if sum == num:
		return True
	else:
		return False
	

num = int(input("Enter a number to check, number is armstrong or not : "))
if is_armstrong(num):
	print("This number is armstrong")
else:
	print("This is not armstrong")

