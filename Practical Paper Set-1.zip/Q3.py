print("Output of a")
a = 10
b = 20
print(a and b)
print(a or b)


print("\n\nOutput of b")
if False:
	print("It is False")
else:
	print("It is True")


print("\n\nOutput of c")
if [ ]:
	print("It is Blank")
else:
	print("It is Something else")


print("\n\nOutput of d")
if [ [ ] ]:
	print("It is Blank")
else:
	print("It is Something else")


print("\n\nOutput of e")
if [ False ]:
	print("It is Blank")
else:
	print("It is Something else")


print("\n\nOutput of f")
type(range)
